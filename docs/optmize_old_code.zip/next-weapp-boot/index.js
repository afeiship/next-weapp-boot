module.exports = {
    App: require('./lib/app'),
    Page: require('./lib/page'),
    Component: require('./lib/component'),
    Behavior: require('./lib/behavior'),
    $ref: require('./lib/ref'),
    $service: require('./lib/service'),
};
